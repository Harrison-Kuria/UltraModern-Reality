package ultramodern.activity.milkdiary_farmer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class Launcher extends AppCompatActivity implements View.OnClickListener {

    Button getstartedbutton;
    private FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);

        getstartedbutton=findViewById(R.id.getstartedbutton);
        getstartedbutton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v==getstartedbutton){
            Intent intent = new Intent(getApplicationContext(),PhoneNumber.class);

            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        }
    }
}

